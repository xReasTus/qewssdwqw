# lydia Bot altyapısı
# TheClawNz#6717 tarafından paylaşılmıştır, lisans TheClawNz#6717'ye aittir izinsiz bir şekilde paylaşmak yasaktır.
# [Tıkla](https://discord.gg/paypal)
